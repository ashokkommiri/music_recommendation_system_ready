# 🎵 Music Recommendation System

This project builds a music recommender using two approaches:

## 💡 Approaches
1. **Content-Based Filtering:** Recommends songs similar to a given one using lyrics and metadata.
2. **Collaborative Filtering:** Recommends songs based on user behavior using KNN and matrix factorization.

## 📁 Folder Structure
- `content_based/`: Content-based filtering using TF-IDF and cosine similarity
- `collaborative/`: Collaborative filtering using KNN and matrix factorization (SVD)

## 📦 Requirements
- Python 3.7+
- pandas
- numpy
- scikit-learn
- jupyter

## 🚀 How to Run
1. Install dependencies: `pip install -r requirements.txt`
2. Open any notebook in Jupyter:
   - `content_based_music_recommender.ipynb`
   - `CF_knn_music_recommender.ipynb`
   - `CF_matrix_fact_music_recommender.ipynb`

## 📊 Dataset
Used a small lyrics dataset (`songdata.csv`). You can plug in your own.

## 👨‍💻 Author
Ashok D.R.L.
